// Fichier : module_facto.c
// À implémenter
