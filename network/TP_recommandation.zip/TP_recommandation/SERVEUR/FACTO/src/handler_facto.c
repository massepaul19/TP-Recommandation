// Fichier : handler_facto.c
// À implémenter
