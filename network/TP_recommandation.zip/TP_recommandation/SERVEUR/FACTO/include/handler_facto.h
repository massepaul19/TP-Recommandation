// Fichier : handler_facto.h
// À implémenter
