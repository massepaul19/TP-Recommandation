// Fichier : serveur_graphe.h
// À implémenter
