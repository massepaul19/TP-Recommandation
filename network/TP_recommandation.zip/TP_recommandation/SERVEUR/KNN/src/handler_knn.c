// Fichier : handler_knn.c
// À implémenter
