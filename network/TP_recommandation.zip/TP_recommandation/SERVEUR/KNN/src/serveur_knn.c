// Fichier : serveur_knn.c
// À implémenter
