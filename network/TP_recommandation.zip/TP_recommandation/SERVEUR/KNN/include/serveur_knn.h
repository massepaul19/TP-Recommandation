// Fichier : serveur_knn.h
// À implémenter
