// Fichier : handler_knn.h
// À implémenter
