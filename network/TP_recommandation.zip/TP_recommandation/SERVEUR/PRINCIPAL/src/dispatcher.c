// Fichier : dispatcher.c
// À implémenter
