// Fichier : session_manager.c
// À implémenter
