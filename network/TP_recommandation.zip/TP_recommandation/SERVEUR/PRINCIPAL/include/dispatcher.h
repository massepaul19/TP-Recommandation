// Fichier : dispatcher.h
// À implémenter
