// Fichier : serveur_common.h
// À implémenter
