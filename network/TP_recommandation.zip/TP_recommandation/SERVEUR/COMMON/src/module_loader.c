// Fichier : module_loader.c
// À implémenter
