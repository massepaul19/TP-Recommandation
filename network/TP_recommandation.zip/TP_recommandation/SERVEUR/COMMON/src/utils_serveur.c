// Fichier : utils_serveur.c
// À implémenter
