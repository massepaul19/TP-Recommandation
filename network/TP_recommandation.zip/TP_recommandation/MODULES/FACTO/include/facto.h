// Fichier : facto.h
// À implémenter
