// Fichier : svd.c
// À implémenter
