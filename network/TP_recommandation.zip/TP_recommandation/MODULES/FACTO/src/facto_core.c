// Fichier : facto_core.c
// À implémenter
