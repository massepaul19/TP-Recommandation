// Fichier : matrix_facto.c
// À implémenter
