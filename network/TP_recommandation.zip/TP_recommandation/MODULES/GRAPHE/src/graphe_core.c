// Fichier : graphe_core.c
// À implémenter
