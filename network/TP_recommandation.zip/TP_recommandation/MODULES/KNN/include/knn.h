// Fichier : knn.h
// À implémenter
