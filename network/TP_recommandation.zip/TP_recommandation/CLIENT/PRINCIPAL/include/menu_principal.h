// Fichier : menu_principal.h
// À implémenter
