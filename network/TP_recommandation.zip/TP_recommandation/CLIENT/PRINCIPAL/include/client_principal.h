// Fichier : client_principal.h
// À implémenter
