#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "../include/menu_principal.h"
//#include "../include/client_principal.h"
//#include "../../KNN/include/client_knn.h"
//#include "../../FACTO/include/client_facto.h"
//#include "../../GRAPHE/include/client_graphe.h"

void afficher_menu_principal() {
    printf("\n");
    printf("╔══════════════════════════════════════════════════════════════╗\n");
    printf("║              SYSTÈME DE RECOMMANDATIONS                     ║\n");
    printf("║                    Version 1.0                              ║\n");
    printf("╠══════════════════════════════════════════════════════════════╣\n");
    printf("║                                                              ║\n");
    printf("║  1. Recommandations par KNN (K-Nearest Neighbors)           ║\n");
    printf("║  2. Recommandations par Factorisation Matricielle           ║\n");
    printf("║  3. Recommandations par Graphe                              ║\n");
    printf("║  4. Comparer les méthodes                                   ║\n");
    printf("║  5. Gérer les datasets                                      ║\n");
    printf("║  6. Afficher les statistiques globales                     ║\n");
    printf("║  7. Configuration système                                   ║\n");
    printf("║  0. Quitter                                                 ║\n");
    printf("║                                                              ║\n");
    printf("╚══════════════════════════════════════════════════════════════╝\n");
    printf("\nVotre choix : ");
}
/*
int executer_menu_principal() {
    int choix;
    int continuer = 1;
    
    // Initialiser la connexion au serveur
    if (initialiser_connexion_serveur() != 0) {
        printf("Erreur: Impossible de se connecter au serveur.\n");
        printf("Veuillez vous assurer que le serveur est démarré.\n");
        return -1;
    }
    
    printf("Connexion au serveur établie avec succès!\n");
    
    while (continuer) {
        afficher_menu_principal();
        
        if (scanf("%d", &choix) != 1) {
            printf("Erreur: Veuillez entrer un nombre valide.\n");
            // Vider le buffer
            while (getchar() != '\n');
            continue;
        }
        
        // Vider le buffer après lecture
        while (getchar() != '\n');
        
        switch (choix) {
            case 1:
                printf("\n=== MODULE KNN SÉLECTIONNÉ ===\n");
                if (executer_menu_knn() != 0) {
                    printf("Erreur lors de l'exécution du module KNN.\n");
                }
                break;
                
            case 2:
                printf("\n=== MODULE FACTORISATION MATRICIELLE SÉLECTIONNÉ ===\n");
                if (executer_menu_facto() != 0) {
                    printf("Erreur lors de l'exécution du module Factorisation.\n");
                }
                break;
                
            case 3:
                printf("\n=== MODULE GRAPHE SÉLECTIONNÉ ===\n");
                if (executer_menu_graphe() != 0) {
                    printf("Erreur lors de l'exécution du module Graphe.\n");
                }
                break;
                
            case 4:
                printf("\n=== COMPARAISON DES MÉTHODES ===\n");
                if (executer_comparaison_methodes() != 0) {
                    printf("Erreur lors de la comparaison des méthodes.\n");
                }
                break;
                
            case 5:
                printf("\n=== GESTION DES DATASETS ===\n");
                if (executer_gestion_datasets() != 0) {
                    printf("Erreur lors de la gestion des datasets.\n");
                }
                break;
                
            case 6:
                printf("\n=== STATISTIQUES GLOBALES ===\n");
                if (afficher_statistiques_globales() != 0) {
                    printf("Erreur lors de l'affichage des statistiques.\n");
                }
                break;
                
            case 7:
                printf("\n=== CONFIGURATION SYSTÈME ===\n");
                if (executer_configuration_systeme() != 0) {
                    printf("Erreur lors de la configuration.\n");
                }
                break;
                
            case 0:
                printf("\n=== ARRÊT DU SYSTÈME ===\n");
                printf("Fermeture de la connexion...\n");
                fermer_connexion_serveur();
                printf("Au revoir!\n");
                continuer = 0;
                break;
                
            default:
                printf("\nChoix invalide. Veuillez choisir une option entre 0 et 7.\n");
                break;
        }
        
        if (continuer && choix != 0) {
            printf("\nAppuyez sur Entrée pour continuer...");
            getchar();
        }
    }
    
    return 0;
}

int executer_comparaison_methodes() {
    printf("\n╔══════════════════════════════════════════════════════════════╗\n");
    printf("║                COMPARAISON DES MÉTHODES                     ║\n");
    printf("╚══════════════════════════════════════════════════════════════╝\n");
    
    printf("\n1. Comparer KNN vs Factorisation\n");
    printf("2. Comparer KNN vs Graphe\n");
    printf("3. Comparer Factorisation vs Graphe\n");
    printf("4. Comparer les trois méthodes\n");
    printf("5. Benchmarker toutes les méthodes\n");
    printf("0. Retour au menu principal\n");
    
    int choix;
    printf("\nVotre choix : ");
    scanf("%d", &choix);
    
    switch (choix) {
        case 1:
            return comparer_knn_facto();
        case 2:
            return comparer_knn_graphe();
        case 3:
            return comparer_facto_graphe();
        case 4:
            return comparer_toutes_methodes();
        case 5:
            return benchmark_methodes();
        case 0:
            return 0;
        default:
            printf("Choix invalide.\n");
            return -1;
    }
}

int executer_gestion_datasets() {
    printf("\n╔══════════════════════════════════════════════════════════════╗\n");
    printf("║                 GESTION DES DATASETS                        ║\n");
    printf("╚══════════════════════════════════════════════════════════════╝\n");
    
    printf("\n1. Lister les datasets disponibles\n");
    printf("2. Charger un nouveau dataset\n");
    printf("3. Valider un dataset\n");
    printf("4. Diviser un dataset (train/test)\n");
    printf("5. Afficher les statistiques d'un dataset\n");
    printf("6. Nettoyer les données\n");
    printf("0. Retour au menu principal\n");
    
    int choix;
    printf("\nVotre choix : ");
    scanf("%d", &choix);
    
    switch (choix) {
        case 1:
            return lister_datasets();
        case 2:
            return charger_dataset();
        case 3:
            return valider_dataset();
        case 4:
            return diviser_dataset();
        case 5:
            return statistiques_dataset();
        case 6:
            return nettoyer_dataset();
        case 0:
            return 0;
        default:
            printf("Choix invalide.\n");
            return -1;
    }
}

int afficher_statistiques_globales() {
    printf("\n╔══════════════════════════════════════════════════════════════╗\n");
    printf("║              STATISTIQUES GLOBALES DU SYSTÈME               ║\n");
    printf("╚══════════════════════════════════════════════════════════════╝\n");
    
    // Envoyer une requête au serveur pour obtenir les statistiques
    if (demander_statistiques_serveur() != 0) {
        printf("Erreur lors de la récupération des statistiques.\n");
        return -1;
    }
    
    return 0;
}

int executer_configuration_systeme() {
    printf("\n╔══════════════════════════════════════════════════════════════╗\n");
    printf("║                CONFIGURATION SYSTÈME                        ║\n");
    printf("╚══════════════════════════════════════════════════════════════╝\n");
    
    printf("\n1. Configurer les paramètres KNN\n");
    printf("2. Configurer les paramètres Factorisation\n");
    printf("3. Configurer les paramètres Graphe\n");
    printf("4. Configurer les chemins des fichiers\n");
    printf("5. Configurer la connexion serveur\n");
    printf("6. Réinitialiser la configuration\n");
    printf("0. Retour au menu principal\n");
    
    int choix;
    printf("\nVotre choix : ");
    scanf("%d", &choix);
    
    switch (choix) {
        case 1:
            return configurer_knn();
        case 2:
            return configurer_facto();
        case 3:
            return configurer_graphe();
        case 4:
            return configurer_chemins();
        case 5:
            return configurer_connexion();
        case 6:
            return reinitialiser_configuration();
        case 0:
            return 0;
        default:
            printf("Choix invalide.\n");
            return -1;
    }
}

*/

int main() {

afficher_menu_principal();

return 0;
}
