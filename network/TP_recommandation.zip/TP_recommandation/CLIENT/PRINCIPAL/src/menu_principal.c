// Fichier : menu_principal.c
// À implémenter
