// Fichier : communication.c
// À implémenter
