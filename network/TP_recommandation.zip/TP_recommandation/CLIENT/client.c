// Fichier : client.c
// À implémenter
