// Fichier : client_knn.c
// À implémenter
