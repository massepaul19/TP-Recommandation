// Fichier : requests_knn.c
// À implémenter
