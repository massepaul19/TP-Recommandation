// Fichier : interface_knn.h
// À implémenter
