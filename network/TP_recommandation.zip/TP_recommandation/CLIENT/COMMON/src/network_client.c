// Fichier : network_client.c
// À implémenter
