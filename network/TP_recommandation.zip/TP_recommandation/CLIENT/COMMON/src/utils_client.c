// Fichier : utils_client.c
// À implémenter
