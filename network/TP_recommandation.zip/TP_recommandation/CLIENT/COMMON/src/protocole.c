// Fichier : protocole.c
// À implémenter
