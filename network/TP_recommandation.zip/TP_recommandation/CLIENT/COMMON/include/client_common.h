// Fichier : client_common.h
// À implémenter
