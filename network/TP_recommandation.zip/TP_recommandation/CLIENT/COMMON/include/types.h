// Fichier : types.h
// À implémenter
