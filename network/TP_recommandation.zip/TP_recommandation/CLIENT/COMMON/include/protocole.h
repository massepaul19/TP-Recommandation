// Fichier : protocole.h
// À implémenter
