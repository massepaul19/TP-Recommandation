// Fichier : client_facto.h
// À implémenter
