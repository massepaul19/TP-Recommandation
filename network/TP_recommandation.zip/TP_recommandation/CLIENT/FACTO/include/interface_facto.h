// Fichier : interface_facto.h
// À implémenter
