// Fichier : menu_facto.c
// À implémenter
