// Fichier : client_facto.c
// À implémenter
