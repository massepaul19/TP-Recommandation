// Fichier : requests_facto.c
// À implémenter
