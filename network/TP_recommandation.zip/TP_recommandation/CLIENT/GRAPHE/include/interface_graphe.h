// Fichier : interface_graphe.h
// À implémenter
