// Fichier : requests_graphe.c
// À implémenter
