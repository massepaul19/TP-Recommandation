// Fichier : menu_graphe.c
// À implémenter
